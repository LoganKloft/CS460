int A()
{
    int a,b;
    a = 1; b = 2;
    B();
}

int B()
{
    int c,d;
    c = 3; d = 4;
}

int C()
{
    return 1;
}